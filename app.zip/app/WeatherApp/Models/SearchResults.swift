

import Foundation

struct SearchResults: Decodable {
    var count: Int?
    var results: DataChannel?
}
