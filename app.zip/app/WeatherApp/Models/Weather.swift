

import Foundation

struct Weather: Decodable {
    var location: Location?
    var item: WeatherItem?
}






