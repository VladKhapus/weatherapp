

import Foundation

struct Location: Decodable {
    var city: String?
    var country: String?
    var region: String?
}
