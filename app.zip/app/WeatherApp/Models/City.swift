

import Foundation

struct City {
    var name: String
    var woeid: String
}
