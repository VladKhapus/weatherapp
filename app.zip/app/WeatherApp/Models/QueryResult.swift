

import Foundation

struct QueryResult: Decodable {
    var query: SearchResults?
}
