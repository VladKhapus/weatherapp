

import Foundation

struct WeatherStatus: Decodable {
    var temp: String?
    var text: String?
}
