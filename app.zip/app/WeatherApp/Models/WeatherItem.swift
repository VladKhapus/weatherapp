

import Foundation


struct WeatherItem: Decodable {
    var condition: WeatherStatus?
}
