

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow()
        window?.makeKeyAndVisible()
        
        let navController = UINavigationController(rootViewController: WeatherController())
        window?.rootViewController = navController
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        let logoViewController = LogoViewController()
        window?.rootViewController?.present(logoViewController, animated: false, completion: nil)
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        window?.rootViewController?.dismiss(animated: false, completion: nil)
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        window?.rootViewController?.dismiss(animated: false, completion: nil)
    }

    func applicationWillTerminate(_ application: UIApplication) {
    }


}

